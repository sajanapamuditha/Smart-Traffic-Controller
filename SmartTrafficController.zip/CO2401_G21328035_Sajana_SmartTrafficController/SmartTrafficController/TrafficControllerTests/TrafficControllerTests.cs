﻿// G21328035 ( Sajana Pamuditha )

using NUnit.Framework;
using System;
using NSubstitute;
using SmartTrafficController;

namespace TrafficControllerTests
{

    // Unit tests for the TrafficController class.
    [TestFixture]
    public class TrafficControllerTests
    {

        // Shared mock objects — re-created before every test
        private IVehicleSignalManager _vehicleSignalManager;
        private IPedestrianSignalManager _pedestrianSignalManager;
        private ITimeManager _timeManager;
        private IWebService _webService;
        private IEmailService _emailService;


        [SetUp]
        public void SetUp()
        {
            _vehicleSignalManager = Substitute.For<IVehicleSignalManager>();
            _pedestrianSignalManager = Substitute.For<IPedestrianSignalManager>();
            _timeManager = Substitute.For<ITimeManager>();
            _webService = Substitute.For<IWebService>();
            _emailService = Substitute.For<IEmailService>();


            _vehicleSignalManager.SetAllRed(Arg.Any<bool>()).Returns(true);
            _vehicleSignalManager.SetAllGreen(Arg.Any<bool>()).Returns(true);
      
            _pedestrianSignalManager.SetWalk(Arg.Any<bool>()).Returns(true);
            _pedestrianSignalManager.SetWait(Arg.Any<bool>()).Returns(true);
            _pedestrianSignalManager.SetAudible(Arg.Any<bool>()).Returns(true);
            _timeManager.Delay(Arg.Any<int>()).Returns(true);
            _webService.FaultDetected(Arg.Any<bool>()).Returns(true);
        }


        // LEVEL 1 TESTS — L1R1 to L1R5


        // L1R1 
        // Constructor with a single string parameter stores the intersection ID.

        [Test]
        public void Constructor_SingleParam_SetsIntersectionID()
        {
       
            var controller = new TrafficController("J01");

            Assert.That(controller.GetIntersectionID(), Is.EqualTo("j01"));
        }

        //  L1R2 
        // Constructor converts uppercase letters in the ID to lowercase.

        [TestCase("ABC123", "abc123")]
        [TestCase("Junction1", "junction1")]
        [TestCase("UPPER", "upper")]
        [TestCase("MiXeD", "mixed")]
        [TestCase("lower", "lower")]
        public void Constructor_SingleParam_ConvertsIDToLowercase(string input, string expected)
        {

            var controller = new TrafficController(input);

            Assert.That(controller.GetIntersectionID(), Is.EqualTo(expected));
        }

        //  L1R3 
        // SetIntersectionID sets the ID and converts uppercase to lowercase.

        [TestCase("NEW_ID", "new_id")]
        [TestCase("ROAD99", "road99")]
        [TestCase("already", "already")]
        public void SetIntersectionID_ConvertsToLowercase(string input, string expected)
        {

            var controller = new TrafficController("old");

            controller.SetIntersectionID(input);

            Assert.That(controller.GetIntersectionID(), Is.EqualTo(expected));
        }


        // SetIntersectionID replaces the previous ID.

        [Test]
        public void SetIntersectionID_ReplacesOldID()
        {

            var controller = new TrafficController("old");

            controller.SetIntersectionID("NewJunction");

            Assert.That(controller.GetIntersectionID(), Is.EqualTo("newjunction"));
        }

        //  L1R4 
        // Constructor sets initial vehicle state to "amber".

        [Test]
        public void Constructor_SingleParam_SetsDefaultVehicleStateToAmber()
        {
          
            var controller = new TrafficController("J01");

            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("amber"));
        }

        // Constructor sets initial pedestrian state to "wait".

        [Test]
        public void Constructor_SingleParam_SetsDefaultPedestrianStateToWait()
        {
   
            var controller = new TrafficController("J01");

            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("wait"));
        }

        //  L1R5 
        // SetStateDirect returns true and sets both states when both inputs are valid.
  
        [TestCase("red", "walk")]
        [TestCase("redamber", "walk")]
        [TestCase("green", "wait")]
        [TestCase("amber", "wait")]
        [TestCase("oosv", "oosp")]
        public void SetStateDirect_ValidStates_ReturnsTrueAndSetsState(string vehicle, string pedestrian)
        {

            var controller = new TrafficController("J01");

            bool result = controller.SetStateDirect(vehicle, pedestrian);

            Assert.That(result, Is.True);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo(vehicle));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo(pedestrian));
        }


        // SetStateDirect is case-insensitive — stores the lowercased version.
        [TestCase("RED", "WALK", "red", "walk")]
        [TestCase("Green", "Wait", "green", "wait")]
        [TestCase("AMBER", "WAIT", "amber", "wait")]
        [TestCase("RedAmber", "Walk", "redamber", "walk")]
        public void SetStateDirect_MixedCaseInputs_StoresLowercase(
            string vehicleIn, string pedIn, string vehicleExpected, string pedExpected)
        {

            var controller = new TrafficController("J01");

            controller.SetStateDirect(vehicleIn, pedIn);

            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo(vehicleExpected));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo(pedExpected));
        }


        // SetStateDirect returns false and leaves state unchanged when vehicle state is invalid.

        [TestCase("invalid", "wait")]
        [TestCase("yellow", "wait")]
        [TestCase("", "wait")]
        [TestCase("PURPLE", "walk")]
        public void SetStateDirect_InvalidVehicleState_ReturnsFalseStateUnchanged(
            string badVehicle, string pedestrian)
        {

            var controller = new TrafficController("J01");
            string originalVehicle = controller.GetCurrentVehicleSignalState();
            string originalPed = controller.GetCurrentPedestrianSignalState();

            bool result = controller.SetStateDirect(badVehicle, pedestrian);

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo(originalVehicle));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo(originalPed));
        }


        // SetStateDirect returns false and leaves state unchanged when pedestrian state is invalid.
  
        [TestCase("red", "invalid")]
        [TestCase("green", "running")]
        [TestCase("amber", "")]
        public void SetStateDirect_InvalidPedestrianState_ReturnsFalseStateUnchanged(
            string vehicle, string badPedestrian)
        {
            var controller = new TrafficController("J01");
            string originalVehicle = controller.GetCurrentVehicleSignalState();
            string originalPed = controller.GetCurrentPedestrianSignalState();

            bool result = controller.SetStateDirect(vehicle, badPedestrian);

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo(originalVehicle));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo(originalPed));
        }


        // LEVEL 2 TESTS — L2R1 to L2R4


        //  L2R1
        // SetCurrentState allows the full legal cycle: amber -> red -> redamber -> green -> amber.

        [Test]
        public void SetCurrentState_FullCycle_EachStepReturnsTrue()
        {

            var controller = BuildControllerWithMocks();

            Assert.That(controller.SetCurrentState("red", "walk"), Is.True, "amber→red");
            Assert.That(controller.SetCurrentState("redamber", "walk"), Is.True, "red→redamber");
            Assert.That(controller.SetCurrentState("green", "wait"), Is.True, "redamber→green");
            Assert.That(controller.SetCurrentState("amber", "wait"), Is.True, "green→amber");
        }


        // SetCurrentState updates vehicle and pedestrian states correctly after each transition.

        [Test]
        public void SetCurrentState_AfterEachValidTransition_BothStatesUpdatedCorrectly()
        {

            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("red"), "vehicle after amber→red");
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("walk"), "pedestrian after amber→red");

            controller.SetCurrentState("redamber", "walk");
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("redamber"), "vehicle after red→redamber");
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("walk"), "pedestrian after red→redamber");

            controller.SetCurrentState("green", "wait");
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("green"), "vehicle after redamber→green");
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("wait"), "pedestrian after redamber→green");

            controller.SetCurrentState("amber", "wait");
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("amber"), "vehicle after green→amber");
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("wait"), "pedestrian after green→amber");
        }


        // SetCurrentState rejects illegal transitions and returns false without changing state.

        [TestCase("amber", "wait", "green", "wait")]
        [TestCase("amber", "wait", "redamber", "walk")]
        [TestCase("amber", "wait", "amber", "wait")]
        [TestCase("red", "walk", "green", "wait")]
        [TestCase("red", "walk", "amber", "wait")]
        [TestCase("green", "wait", "red", "walk")]
        [TestCase("redamber", "walk", "amber", "wait")]
        public void SetCurrentState_IllegalTransition_ReturnsFalseStateUnchanged(
            string startVehicle, string startPed, string targetVehicle, string targetPed)
        {
 
            var controller = BuildControllerWithMocks();
            controller.SetStateDirect(startVehicle, startPed);

            bool result = controller.SetCurrentState(targetVehicle, targetPed);

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo(startVehicle));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo(startPed));
        }

        // SetCurrentState rejects entirely unrecognised state names.

        [TestCase("yellow", "wait")]
        [TestCase("amber", "running")]
        [TestCase("invalid", "invalid")]
        public void SetCurrentState_UnrecognisedStateNames_ReturnsFalse(
            string badVehicle, string badPed)
        {

            var controller = BuildControllerWithMocks();

            bool result = controller.SetCurrentState(badVehicle, badPed);

            Assert.That(result, Is.False);
        }


        // red -> redamber enforces pedestrian state as "walk" regardless of caller argument.

        [Test]
        public void SetCurrentState_RedToRedAmber_PedestrianAlwaysEnforcedAsWalk()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");

            controller.SetCurrentState("redamber", "wait");

            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("walk"));
        }


        // green -> amber enforces pedestrian state as "wait" regardless of caller argument.

        [Test]
        public void SetCurrentState_GreenToAmber_PedestrianAlwaysEnforcedAsWait()
        {
        
            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");
            controller.SetCurrentState("green", "wait");

            controller.SetCurrentState("amber", "walk");

            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("wait"));
        }

        // L2R2 

        // Three-parameter constructor accepts valid states in any case and stores lowercase.
  
        [TestCase("red", "walk", "red", "walk")]
        [TestCase("GREEN", "WAIT", "green", "wait")]
        [TestCase("Amber", "Walk", "amber", "walk")]
        [TestCase("REDAMBER", "WAIT", "redamber", "wait")]
        public void Constructor_ThreeParams_AcceptsValidStatesAndStoresLowercase(
            string vehicleIn, string pedIn, string vehicleExpected, string pedExpected)
        {

            var controller = new TrafficController("J01", vehicleIn, pedIn);

  
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo(vehicleExpected));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo(pedExpected));
        }


        // Three-parameter constructor throws ArgumentException for invalid vehicle states.
 
        [TestCase("oosv", "wait")]
        [TestCase("yellow", "wait")]
        [TestCase("invalid", "wait")]
        [TestCase("", "wait")]
        public void Constructor_ThreeParams_InvalidVehicleState_ThrowsArgumentException(
            string badVehicle, string pedestrian)
        {

            Assert.Throws<ArgumentException>(() =>
                new TrafficController("J01", badVehicle, pedestrian));
        }

        // Three-parameter constructor throws ArgumentException for invalid pedestrian states.

        [TestCase("red", "oosp")]
        [TestCase("green", "invalid")]
        [TestCase("amber", "")]
        public void Constructor_ThreeParams_InvalidPedestrianState_ThrowsArgumentException(
            string vehicle, string badPedestrian)
        {
   
            Assert.Throws<ArgumentException>(() =>
                new TrafficController("J01", vehicle, badPedestrian));
        }


        // ArgumentException message matches the exact wording specified in the brief.

        [Test]
        public void Constructor_ThreeParams_InvalidStates_ExceptionMessageMatchesSpec()
        {

            const string expectedMessage =
                "Argument Exception: TrafficController can only be initialised to the following states: " +
                "'green', 'amber', 'red', 'redamber' for the vehicle signals and " +
                "'wait' or 'walk' for the pedestrian signal";

            var ex = Assert.Throws<ArgumentException>(() =>
                new TrafficController("J01", "oosv", "oosp"));

            Assert.That(ex.Message, Is.EqualTo(expectedMessage));
        }


        // Three-parameter constructor also stores the ID in lowercase.

        [Test]
        public void Constructor_ThreeParams_ConvertsIDToLowercase()
        {

            var controller = new TrafficController("JUNCTION_A", "red", "walk");

            // Assert
            Assert.That(controller.GetIntersectionID(), Is.EqualTo("junction_a"));
        }

        // L2R3 
        // Six-parameter dependency injection constructor sets default amber/wait states.

        [Test]
        public void Constructor_SixParams_SetsDefaultAmberWaitStates()
        {

            var controller = BuildControllerWithMocks();

            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("amber"));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("wait"));
        }


        // Injected IVehicleSignalManager is called during amber -> red transition.

        [Test]
        public void Constructor_SixParams_VehicleManagerCalledOnAmberToRed()
        {
      
            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");

            _vehicleSignalManager.Received(1).SetAllRed(true);
        }


        // Injected IPedestrianSignalManager is called during amber -> red transition.

        [Test]
        public void Constructor_SixParams_PedestrianManagerCalledOnAmberToRed()
        {

            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");

            _pedestrianSignalManager.Received(1).SetWalk(true);
        }

        // L2R4 

        // GetStatusReport returns concatenated status strings in vehicle -> pedestrian -> timer order.

        [Test]
        public void GetStatusReport_ConcatenatesInCorrectOrder_VehiclePedestrianTimer()
        {

            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,OK,OK,OK,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,OK,OK,");
            _timeManager.GetStatus().Returns("Timer,OK,OK,");
            var controller = BuildControllerWithMocks();

            string report = controller.GetStatusReport();

            Assert.That(report, Is.EqualTo(
                "VehicleSignal,OK,OK,OK,PedestrianSignal,OK,OK,Timer,OK,OK,"));
        }


        // GetStatusReport calls GetStatus on all three managers exactly once.
  
        [Test]
        public void GetStatusReport_CallsGetStatusOnAllThreeManagers()
        {

            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,OK,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,OK,");
            _timeManager.GetStatus().Returns("Timer,OK,");
            var controller = BuildControllerWithMocks();

            controller.GetStatusReport();


            _vehicleSignalManager.Received(1).GetStatus();
            _pedestrianSignalManager.Received(1).GetStatus();
            _timeManager.Received(1).GetStatus();
        }

        // LEVEL 3 TESTS — L3R1 to L3R5


        // L3R1 
        // amber -> red calls ITimeManager.Delay(3) as the first action.

        [Test]
        public void SetCurrentState_AmberToRed_CallsWait3Seconds()
        {

            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");

            _timeManager.Received().Delay(3);
        }

        // amber -> red calls IVehicleSignalManager.SetAllRed(true).

        [Test]
        public void SetCurrentState_AmberToRed_CallsSetAllRedTrue()
        {
   
            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");

            _vehicleSignalManager.Received(1).SetAllRed(true);
        }


        // amber -> red calls IPedestrianSignalManager.SetWalk(true).

        [Test]
        public void SetCurrentState_AmberToRed_CallsSetWalkTrue()
        {
     
            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");

            _pedestrianSignalManager.Received(1).SetWalk(true);
        }


        // amber -> red calls IPedestrianSignalManager.SetAudible(true).

        [Test]
        public void SetCurrentState_AmberToRed_CallsSetAudibleTrue()
        {
 
            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");

            _pedestrianSignalManager.Received(1).SetAudible(true);
        }


        // amber -> red holds at red for 60 seconds — Wait(60) must be called.
        [Test]
        public void SetCurrentState_AmberToRed_CallsWait60SecondsAfterTransition()
        {

            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");

            _timeManager.Received().Delay(60);
        }


        // amber -> red returns false and does not change state if Wait(3) fails.

        [Test]
        public void SetCurrentState_AmberToRed_Wait3Fails_ReturnsFalseStateUnchanged()
        {

            _timeManager.Delay(3).Returns(false);
            var controller = BuildControllerWithMocks();

            bool result = controller.SetCurrentState("red", "walk");

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("amber"));
        }


        // amber -> red returns false and does not change state if SetAllRed(true) fails.

        [Test]
        public void SetCurrentState_AmberToRed_SetAllRedFails_ReturnsFalseStateUnchanged()
        {

            _vehicleSignalManager.SetAllRed(true).Returns(false);
            var controller = BuildControllerWithMocks();

            bool result = controller.SetCurrentState("red", "walk");

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("amber"));
        }


        // amber -> red returns false and does not change state if SetWalk(true) fails.

        [Test]
        public void SetCurrentState_AmberToRed_SetWalkTrueFails_ReturnsFalseStateUnchanged()
        {

            _pedestrianSignalManager.SetWalk(true).Returns(false);
            var controller = BuildControllerWithMocks();

            bool result = controller.SetCurrentState("red", "walk");

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("amber"));
        }


        // amber -> red returns false and does not change state if SetAudible(true) fails.

        [Test]
        public void SetCurrentState_AmberToRed_SetAudibleFails_ReturnsFalseStateUnchanged()
        {

            _pedestrianSignalManager.SetAudible(true).Returns(false);
            var controller = BuildControllerWithMocks();

            bool result = controller.SetCurrentState("red", "walk");

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("amber"));
        }

        //  L3R2 
        // redamber -> green calls ITimeManager.Delay(3) first.
        [Test]
        public void SetCurrentState_RedAmberToGreen_CallsDelay3Seconds()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");
            _timeManager.ClearReceivedCalls();

            controller.SetCurrentState("green", "wait");

            _timeManager.Received().Delay(3);
        }


        // redamber -> green calls SetWalk(false) to disable the walk signal.

        [Test]
        public void SetCurrentState_RedAmberToGreen_CallsSetWalkFalse()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");

            controller.SetCurrentState("green", "wait");

            _pedestrianSignalManager.Received(1).SetWalk(false);
        }


        // redamber -> green calls SetWait(true) to enable the wait signal.

        [Test]
        public void SetCurrentState_RedAmberToGreen_CallsSetWaitTrue()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");

            controller.SetCurrentState("green", "wait");

            _pedestrianSignalManager.Received(1).SetWait(true);
        }


        // redamber -> green calls SetAudible(false) to disable the audible indicator.

        [Test]
        public void SetCurrentState_RedAmberToGreen_CallsSetAudibleFalse()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");

            controller.SetCurrentState("green", "wait");

            _pedestrianSignalManager.Received(1).SetAudible(false);
        }


        // redamber -> green calls SetAllGreen(true).

        [Test]
        public void SetCurrentState_RedAmberToGreen_CallsSetAllGreenTrue()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");

            controller.SetCurrentState("green", "wait");

            _vehicleSignalManager.Received(1).SetAllGreen(true);
        }


        // redamber -> green holds at green for 120 seconds — Wait(120) must be called.

        [Test]
        public void SetCurrentState_RedAmberToGreen_CallsDelay120Seconds()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");

            controller.SetCurrentState("green", "wait");

            _timeManager.Received().Delay(120);
        }


        // redamber -> green returns false and does not change state if SetAllGreen(true) fails.

        [Test]
        public void SetCurrentState_RedAmberToGreen_SetAllGreenFails_ReturnsFalseStateUnchanged()
        {

            _vehicleSignalManager.SetAllGreen(true).Returns(false);
            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");

            bool result = controller.SetCurrentState("green", "wait");

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("redamber"));
        }

        // redamber -> green returns false and does not change state if SetWalk(false) fails.

        [Test]
        public void SetCurrentState_RedAmberToGreen_SetWalkFalseFails_ReturnsFalseStateUnchanged()
        {

            _pedestrianSignalManager.SetWalk(false).Returns(false);
            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");

            bool result = controller.SetCurrentState("green", "wait");

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("redamber"));
        }

        // L3R3 
        // SetCurrentState("oosv", "oosp") transitions to out-of-service and returns true.

        [Test]
        public void SetCurrentState_ToOosv_TransitionsSuccessfullyAndReturnsTrue()
        {

            var controller = BuildControllerWithMocks();

            bool result = controller.SetCurrentState("oosv", "oosp");

            Assert.That(result, Is.True);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("oosv"));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("oosp"));
        }


        // Entering OOS calls IWebService.FaultDetected(true).
        [Test]
        public void SetCurrentState_ToOosv_CallsFaultDetectedTrue()
        {

            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("oosv", "oosp");

            _webService.Received(1).FaultDetected(true);
        }


        // Entering OOS calls IWebService.LogEngineerRequired("out of service").

        [Test]
        public void SetCurrentState_ToOosv_CallsLogEngineerRequiredWithOutOfService()
        {

            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("oosv", "oosp");

            _webService.Received(1).LogEngineerRequired("out of service");
        }


        // If FaultDetected(true) returns false, state must NOT change and method returns false.

        [Test]
        public void SetCurrentState_ToOosv_FaultDetectedReturnsFalse_StateUnchanged()
        {

            _webService.FaultDetected(true).Returns(false);
            var controller = BuildControllerWithMocks();

            bool result = controller.SetCurrentState("oosv", "oosp");

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("amber"));
        }


        // History state (H) is saved on OOS entry; exit returns to that exact state.

        [Test]
        public void SetCurrentState_ToOosv_HistoryPreserved_ExitReturnsToHistoryState()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");
            controller.SetCurrentState("green", "wait");

            controller.SetCurrentState("oosv", "oosp");
            bool exitResult = controller.SetCurrentState("green", "wait");

            Assert.That(exitResult, Is.True);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("green"));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("wait"));
        }

        // OOS exit to a state different from the saved history state must be rejected.

        [Test]
        public void SetCurrentState_FromOosv_WrongHistoryTarget_ReturnsFalseAndStaysInOos()
        {
      
            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("oosv", "oosp");

            bool result = controller.SetCurrentState("green", "wait");

            Assert.That(result, Is.False);
            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("oosv"));
        }

        //  L3R4 
        // GetStatusReport calls LogEngineerRequired("VehicleSignal,") when only vehicle has a fault.

        [Test]
        public void GetStatusReport_VehicleFaultOnly_LogsVehicleSignalDevice()
        {

            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,OK,FAULT,OK,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,OK,OK,");
            _timeManager.GetStatus().Returns("Timer,OK,OK,");
            var controller = BuildControllerWithMocks();

            controller.GetStatusReport();

            _webService.Received(1).LogEngineerRequired("VehicleSignal,");
        }


        // GetStatusReport passes all faulty device types comma-separated in one call.

        [Test]
        public void GetStatusReport_VehicleAndPedestrianFaulty_LogsBothDeviceTypes()
        {

            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,OK,FAULT,OK,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,FAULT,OK,");
            _timeManager.GetStatus().Returns("Timer,OK,OK,");
            var controller = BuildControllerWithMocks();

            controller.GetStatusReport();

            _webService.Received(1).LogEngineerRequired("VehicleSignal,PedestrianSignal,");
        }


        // GetStatusReport with all three devices faulty logs all three device types.

        [Test]
        public void GetStatusReport_AllDevicesFaulty_LogsAllThreeDeviceTypes()
        {

            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,FAULT,FAULT,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,FAULT,OK,");
            _timeManager.GetStatus().Returns("Timer,FAULT,OK,");
            var controller = BuildControllerWithMocks();

            controller.GetStatusReport();

            _webService.Received(1).LogEngineerRequired(
                "VehicleSignal,PedestrianSignal,Timer,");
        }


        // GetStatusReport does NOT call LogEngineerRequired when all devices are OK.

        [Test]
        public void GetStatusReport_NoFaults_DoesNotCallLogEngineerRequired()
        {

            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,OK,OK,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,OK,OK,");
            _timeManager.GetStatus().Returns("Timer,OK,OK,");
            var controller = BuildControllerWithMocks();

            controller.GetStatusReport();

            _webService.DidNotReceive().LogEngineerRequired(Arg.Any<string>());
        }

        // L3R5 
        // When LogEngineerRequired throws in GetStatusReport, SendMail is called with
        // the correct recipient address, subject, and the exception message as the body.

        [Test]
        public void GetStatusReport_LogEngineerRequiredThrows_SendsEmailToCorrectAddress()
        {
 
            const string exceptionMessage = "Connection timeout";
            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,FAULT,OK,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,OK,");
            _timeManager.GetStatus().Returns("Timer,OK,");
            _webService
                .When(w => w.LogEngineerRequired(Arg.Any<string>()))
                .Do(_ => throw new Exception(exceptionMessage));
            var controller = BuildControllerWithMocks();

            controller.GetStatusReport();

            _emailService.Received(1).SendMail(
                "transportoffice@gmail.com",
                "failed to log out of service",
                exceptionMessage);
        }


        // When LogEngineerRequired throws during OOS entry in SetCurrentState,
        // SendMail is called with the exception message.

        [Test]
        public void SetCurrentState_ToOosv_LogEngineerRequiredThrows_SendsEmailWithExceptionMessage()
        {

            const string exceptionMessage = "Service unavailable";
            _webService
                .When(w => w.LogEngineerRequired(Arg.Any<string>()))
                .Do(_ => throw new Exception(exceptionMessage));
            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("oosv", "oosp");


            _emailService.Received(1).SendMail(
                "transportoffice@gmail.com",
                "failed to log out of service",
                exceptionMessage);
        }


        // When LogEngineerRequired throws, the exception must NOT propagate to the caller.

        [Test]
        public void GetStatusReport_LogEngineerRequiredThrows_ExceptionNotPropagatedToCaller()
        {

            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,FAULT,OK,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,OK,");
            _timeManager.GetStatus().Returns("Timer,OK,");
            _webService
                .When(w => w.LogEngineerRequired(Arg.Any<string>()))
                .Do(_ => throw new Exception("network error"));
            var controller = BuildControllerWithMocks();

            Assert.DoesNotThrow(() => controller.GetStatusReport());
        }


        // INTEGRATION TESTS — full scenario end-to-end coverage

        // Integration: full legal cycle verifies all hardware calls are made.

        [Test]
        public void FullCycle_AllHardwareCallsMadeCorrectly()
        {

            var controller = BuildControllerWithMocks();

            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");
            controller.SetCurrentState("green", "wait");
            controller.SetCurrentState("amber", "wait");

            _vehicleSignalManager.Received(1).SetAllRed(true);
            _pedestrianSignalManager.Received(1).SetWalk(true);   
            _pedestrianSignalManager.Received(1).SetAudible(true);
            _pedestrianSignalManager.Received(1).SetWalk(false);
            _pedestrianSignalManager.Received(1).SetWait(true);
            _pedestrianSignalManager.Received(1).SetAudible(false);
            _vehicleSignalManager.Received(1).SetAllGreen(true);
        }


        // Integration: OOS entered from green/wait, exit returns to green/wait correctly.

        [Test]
        public void OosIntegration_EnteredFromGreen_ExitCorrectlyReturnsToGreen()
        {

            var controller = BuildControllerWithMocks();
            controller.SetCurrentState("red", "walk");
            controller.SetCurrentState("redamber", "walk");
            controller.SetCurrentState("green", "wait");


            controller.SetCurrentState("oosv", "oosp");
            controller.SetCurrentState("green", "wait");


            Assert.That(controller.GetCurrentVehicleSignalState(), Is.EqualTo("green"));
            Assert.That(controller.GetCurrentPedestrianSignalState(), Is.EqualTo("wait"));
        }


        // Integration: GetStatusReport still returns the correct concatenated string

        [Test]
        public void GetStatusReport_WhenLoggingFails_StillReturnsConcatenatedStatusString()
        {
  
            _vehicleSignalManager.GetStatus().Returns("VehicleSignal,FAULT,OK,");
            _pedestrianSignalManager.GetStatus().Returns("PedestrianSignal,OK,");
            _timeManager.GetStatus().Returns("Timer,OK,");
            _webService
                .When(w => w.LogEngineerRequired(Arg.Any<string>()))
                .Do(_ => throw new Exception("error"));
            var controller = BuildControllerWithMocks();

            string report = controller.GetStatusReport();

            Assert.That(report, Is.EqualTo(
                "VehicleSignal,FAULT,OK,PedestrianSignal,OK,Timer,OK,"));
        }


        // Private Helper

        // Builds a TrafficController with all five mocks injected.
        // Starts in the default amber / wait state.

        private TrafficController BuildControllerWithMocks()
        {
            return new TrafficController(
                "J01",
                _vehicleSignalManager,
                _pedestrianSignalManager,
                _timeManager,
                _webService,
                _emailService);
        }
    }
}