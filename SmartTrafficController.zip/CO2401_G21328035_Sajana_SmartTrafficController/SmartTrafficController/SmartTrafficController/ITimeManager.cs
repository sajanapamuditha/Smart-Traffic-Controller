﻿namespace SmartTrafficController
{
    public interface ITimeManager
    {
  
        // Returns a comma-separated status string for all managed timer channels.
        string GetStatus();

        
        // Waits for the specified number of seconds before returning.
        bool Delay(int time);
    }
}