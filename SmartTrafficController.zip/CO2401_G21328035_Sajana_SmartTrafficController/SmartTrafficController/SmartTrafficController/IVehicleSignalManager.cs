﻿namespace SmartTrafficController
{
    public interface IVehicleSignalManager
    {

        // Returns a comma-separated status string for all managed vehicle signal channels.

        string GetStatus();

   
        // Sets all vehicle signals to RED across both directions.
      
        bool SetAllRed(bool on);

        // Enables or disables the green signal across all vehicle channels.

        bool SetAllGreen(bool on);
    }
}