﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SmartTrafficController
{
    // Controls vehicle and pedestrian traffic signals at a single intersection
    public class TrafficController
    {
        //  Private Fields 

        private string intersectionID;
        private string currentVehicleSignalState;
        private string currentPedestrianSignalState;
        private string historyVehicleState;
        private string historyPedestrianState;

        // Hardware dependency references — injected via the DI constructor, null otherwise
        private readonly IVehicleSignalManager vehicleSignalManager;
        private readonly IPedestrianSignalManager pedestrianSignalManager;
        private readonly ITimeManager timeManager;
        private readonly IWebService webService;
        private readonly IEmailService emailService;

        // Valid State Sets 

        private static readonly string[] ValidVehicleStates =
            { "red", "redamber", "green", "amber", "oosv" };

        private static readonly string[] ValidPedestrianStates =
            { "wait", "walk", "oosp" };

        private static readonly string[] NormalVehicleStates =
            { "red", "redamber", "green", "amber" };

        private static readonly string[] NormalPedestrianStates =
            { "wait", "walk" };


        //  State Transition Table 

        // Maps each vehicle state to the only state it is legally allowed to transition to
        private static readonly Dictionary<string, string[]> VehicleTransitions =
            new Dictionary<string, string[]>
        {
            { "amber",    new[] { "red"      } },
            { "red",      new[] { "redamber" } },
            { "redamber", new[] { "green"    } },
            { "green",    new[] { "amber"    } },
        };


        //  Constructor 1 — L1R1, L1R2, L1R4 
        // Basic constructor — takes intersection ID only, sets default amber/wait states
        public TrafficController(string id)
        {

            intersectionID = id.ToLower();

            currentVehicleSignalState = "amber";
            currentPedestrianSignalState = "wait";

            historyVehicleState = "amber";
            historyPedestrianState = "wait";
        }

        //  Constructor 2 — L2R2 
        // Custom start-state constructor — throws ArgumentException if states are invalid
        public TrafficController(string id, string vehicleStartState, string pedestrianStartState)
        {

            string v = vehicleStartState.ToLower();
            string p = pedestrianStartState.ToLower();

            if (!NormalVehicleStates.Contains(v) || !NormalPedestrianStates.Contains(p))
            {

                throw new ArgumentException(
                    "Argument Exception: TrafficController can only be initialised to the following states: " +
                    "'green', 'amber', 'red', 'redamber' for the vehicle signals and " +
                    "'wait' or 'walk' for the pedestrian signal");
            }

            intersectionID = id.ToLower();
            currentVehicleSignalState = v;
            currentPedestrianSignalState = p;
            historyVehicleState = v;
            historyPedestrianState = p;
        }

        //  Constructor 3 — L2R3 
        // Dependency injection constructor — accepts all 5 interfaces for unit testing
        public TrafficController(
            string id,
            IVehicleSignalManager iVehicleSignalManager,
            IPedestrianSignalManager iPedestrianSignalManager,
            ITimeManager iTimeManager,
            IWebService iWebService,
            IEmailService iEmailService)
        {
            // Set default states and store all injected dependencies
            intersectionID = id.ToLower();
            currentVehicleSignalState = "amber";
            currentPedestrianSignalState = "wait";
            historyVehicleState = "amber";
            historyPedestrianState = "wait";

            vehicleSignalManager = iVehicleSignalManager;
            pedestrianSignalManager = iPedestrianSignalManager;
            timeManager = iTimeManager;
            webService = iWebService;
            emailService = iEmailService;
        }

        //  Getters 
        public string GetIntersectionID() => intersectionID;
        public string GetCurrentVehicleSignalState() => currentVehicleSignalState;
        public string GetCurrentPedestrianSignalState() => currentPedestrianSignalState;


        // SetIntersectionID — L1R3 
        // Updates the intersection ID, converting uppercase letters to lowercase
        public void SetIntersectionID(string id)
        {

            intersectionID = id.ToLower();
        }

        //  SetStateDirect — L1R5 
        // Directly sets both signal states, bypassing transition-order rules
        public bool SetStateDirect(string vehicleSignalState, string pedestrianSignalState)
        {

            string v = vehicleSignalState.ToLower();
            string p = pedestrianSignalState.ToLower();


            if (!ValidVehicleStates.Contains(v) || !ValidPedestrianStates.Contains(p))
                return false;

            currentVehicleSignalState = v;
            currentPedestrianSignalState = p;

    
            if (NormalVehicleStates.Contains(v)) historyVehicleState = v;
            if (NormalPedestrianStates.Contains(p)) historyPedestrianState = p;

            return true;
        }

        //  SetCurrentState — L2R1, L3R1, L3R2, L3R3 
        // Attempts a state transition following the Appendix B state diagram

        public bool SetCurrentState(string vehicleSignal, string pedestrianSignal)
        {

            string v = vehicleSignal.ToLower();
            string p = pedestrianSignal.ToLower();

            if (!ValidVehicleStates.Contains(v) || !ValidPedestrianStates.Contains(p))
                return false;

            // Exit out-of-service: only allowed to return to the exact pre-OOS history state
            if (currentVehicleSignalState == "oosv")
            {
                if (v == historyVehicleState && p == historyPedestrianState)
                {
                    currentVehicleSignalState = v;
                    currentPedestrianSignalState = p;
                    return true;
                }
                return false;
            }

            // Enter out-of-service — L3R3
            if (v == "oosv" && p == "oosp")
            {

                string savedVehicle = currentVehicleSignalState;
                string savedPedestrian = currentPedestrianSignalState;

                if (webService != null && !webService.FaultDetected(true))
                    return false;

                historyVehicleState = savedVehicle;
                historyPedestrianState = savedPedestrian;
                currentVehicleSignalState = "oosv";
                currentPedestrianSignalState = "oosp";

                // Log to web service; fall back to email if logging throws — L3R3, L3R5
                if (webService != null)
                {
                    try
                    {
                        webService.LogEngineerRequired("out of service");
                    }
                    catch (Exception ex)
                    {
                        // L3R5: send maintenance email when web service logging fails
                        emailService?.SendMail(
                            "transportoffice@gmail.com",
                            "failed to log out of service",
                            ex.Message);
                    }
                }

                return true;
            }

            // Reject if current state has no outgoing transitions defined
            if (!VehicleTransitions.ContainsKey(currentVehicleSignalState))
                return false;

            // Reject if the target vehicle state is not reachable from the current state
            if (!VehicleTransitions[currentVehicleSignalState].Contains(v))
                return false;

            // amber -> red — L3R1
            if (currentVehicleSignalState == "amber" && v == "red")
            {

                if (timeManager != null && !timeManager.Delay(3))
                    return false;

                if (vehicleSignalManager != null && !vehicleSignalManager.SetAllRed(true))
                    return false;


                if (pedestrianSignalManager != null)
                {
                    if (!pedestrianSignalManager.SetWalk(true)) return false;
                    if (!pedestrianSignalManager.SetAudible(true)) return false;
                }

                // Commit state only after all hardware calls succeed
                currentVehicleSignalState = "red";
                currentPedestrianSignalState = "walk";
                historyVehicleState = "red";
                historyPedestrianState = "walk";


                timeManager?.Delay(60);

                return true;
            }

            // redamber -> green — L3R2
            if (currentVehicleSignalState == "redamber" && v == "green")
            {

                if (timeManager != null && !timeManager.Delay(3))
                    return false;

                if (pedestrianSignalManager != null)
                {
                    if (!pedestrianSignalManager.SetWalk(false)) return false;
                    if (!pedestrianSignalManager.SetWait(true)) return false;
                    if (!pedestrianSignalManager.SetAudible(false)) return false;
                }


                if (vehicleSignalManager != null && !vehicleSignalManager.SetAllGreen(true))
                    return false;

                // Commit state only after all hardware calls succeed
                currentVehicleSignalState = "green";
                currentPedestrianSignalState = "wait";
                historyVehicleState = "green";
                historyPedestrianState = "wait";


                timeManager?.Delay(120);

                return true;
            }

            // red -> redamber — no hardware calls needed, pedestrians still crossing
            if (currentVehicleSignalState == "red" && v == "redamber")
            {
                currentVehicleSignalState = "redamber";
                currentPedestrianSignalState = "walk";
                historyVehicleState = "redamber";
                historyPedestrianState = "walk";
                return true;
            }

            // green -> amber — no hardware calls needed, pedestrians still waiting
            if (currentVehicleSignalState == "green" && v == "amber")
            {
                currentVehicleSignalState = "amber";
                currentPedestrianSignalState = "wait";
                historyVehicleState = "amber";
                historyPedestrianState = "wait";
                return true;
            }


            return false;
        }

        //  GetStatusReport — L2R4, L3R4, L3R5 

        public string GetStatusReport()
        {

            string vehicleStatus = vehicleSignalManager != null ? vehicleSignalManager.GetStatus() : "";
            string pedestrianStatus = pedestrianSignalManager != null ? pedestrianSignalManager.GetStatus() : "";
            string timerStatus = timeManager != null ? timeManager.GetStatus() : "";

            // L3R4: check each status string for FAULT and collect faulty device names
            if (webService != null)
            {
                string faultyDevices = "";

                if (vehicleStatus.Contains("FAULT"))
                    faultyDevices += ExtractDeviceType(vehicleStatus) + ",";

                if (pedestrianStatus.Contains("FAULT"))
                    faultyDevices += ExtractDeviceType(pedestrianStatus) + ",";

                if (timerStatus.Contains("FAULT"))
                    faultyDevices += ExtractDeviceType(timerStatus) + ",";

                // If any faults found, log the faulty device names to the web service
                if (faultyDevices.Length > 0)
                {
                    try
                    {
                        webService.LogEngineerRequired(faultyDevices);
                    }
                    catch (Exception ex)
                    {
                        emailService?.SendMail(
                            "transportoffice@gmail.com",
                            "failed to log out of service",
                            ex.Message);
                    }
                }
            }

            return vehicleStatus + pedestrianStatus + timerStatus;
        }

        //  Private Helper 
        // Extracts the device type name from a comma-separated status string

        private string ExtractDeviceType(string statusString)
        {
            if (string.IsNullOrEmpty(statusString)) return "";
            int comma = statusString.IndexOf(',');
            return comma < 0 ? statusString : statusString.Substring(0, comma);
        }
    }
}