﻿namespace SmartTrafficController
{
    public interface IEmailService
    {

        // Sends an email to the specified recipient.
        void SendMail(string to, string subject, string message);
    }
}