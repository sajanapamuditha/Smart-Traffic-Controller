﻿namespace SmartTrafficController
{
    public interface IPedestrianSignalManager
    {

        // Returns a comma-separated status string for all managed pedestrian signal channels.
        string GetStatus();

        // Enables or disables the pedestrian WALK signal.
        bool SetWalk(bool on);

        // Enables or disables the pedestrian WAIT signal.
        bool SetWait(bool on);

        // Enables or disables the audible indicator for pedestrians.
        bool SetAudible(bool on);
    }
}