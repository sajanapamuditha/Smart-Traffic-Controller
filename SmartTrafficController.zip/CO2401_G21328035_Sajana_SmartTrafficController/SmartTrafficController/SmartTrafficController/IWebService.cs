﻿namespace SmartTrafficController
{
    public interface IWebService
    {

        // Logs that an engineer is required, passing the type(s) of device that need attention.

        void LogEngineerRequired(string message);


        // Triggers a fault detected event, moving signals to out-of-service states.

        bool FaultDetected(bool on);
    }
}